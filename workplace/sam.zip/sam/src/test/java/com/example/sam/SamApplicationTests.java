package com.example.sam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SamApplicationTests {

	@Test
	void contextLoads() {
	}

}
